from flask import Flask, render_template, request, redirect, url_for
import xml.etree.ElementTree as ET
import bcrypt
import sys
# generate a salt value
salt = bcrypt.gensalt(4)

# hash the password using the salt value
# password = 'test123'.encode('utf-8')
# hashed_password = bcrypt.hashpw(password, salt)

from lxml import etree

def parse_users_xml():
    tree = etree.parse('users.xml')
    users = []
    for user_elem in tree.xpath('/users/user'):
        user = {
            'username': user_elem.xpath('username/text()')[0],
            'password': user_elem.xpath('password_hash/text()')[0]
        }
        users.append(user)
    return users

app = Flask(__name__)
users = parse_users_xml()

@app.route('/login')
def login():
    return render_template('login.html')

# Define route to handle form submissions
@app.route('/submit', methods=['POST'])
def submit():
    # Get form data
    name = request.form['name']
    email = request.form['email']
    password = request.form['password']

    # Hash password using bcrypt
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    print(hashed_password, file=sys.stderr)
    print(type(hashed_password), file=sys.stderr)
                
    # Create XML element for new user
    user = ET.Element("user")
    username = ET.SubElement(user, "username")
    username.text = name
    email_address = ET.SubElement(user, "email")
    email_address.text = email
    password_hash = ET.SubElement(user, "password_hash")
    password_hash.text = hashed_password.decode('ascii')

    # Add new user to XML file
    tree = ET.parse('users.xml')
    root = tree.getroot()
    root.append(user)
    tree.write('users.xml')

    # Redirect to success page
    return redirect(url_for('success'))

# Define route for success page
@app.route('/success')
def success():
     return render_template('success.html')


@app.route('/getlogin', methods=[ 'POST'])
def getlogin():
        print("hai", file=sys.stderr)
        username = request.form['username']
        password = request.form['password']
        hashed =   bcrypt.hashpw(password.encode('utf-8'),salt)
        users = parse_users_xml()
        for user in users:
             print(user, file=sys.stderr)
        for user in users:
            print(user['username'],username, file=sys.stderr)

            if   user['username'].__eq__(username):
                print("correct pass", file=sys.stderr)
                
                try:
                    print("db",user['password'].encode("ascii"), file=sys.stderr)
                    print("new",hashed, file=sys.stderr)
                except KeyError:
                    print("Email key does not exist in the user dictionary.", file=sys.stderr)
                

                if bcrypt.checkpw(password.encode('ascii'), user['password'].encode('ascii')):
                    return 'Logged in successfully!'
                else:
                    return 'Incorrect password!'
                
           
        return 'User not found! Please Create New User to login or contact adiministrator'

@app.route('/', methods=['GET'])
def login_submit():
        return render_template('index.html')

@app.route('/about/')
def about():
    return render_template('about.html')
if __name__ == '__main__':
    app.run(debug=True)
